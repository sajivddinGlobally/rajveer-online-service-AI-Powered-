



import 'package:ai_powered_app/data/models/jobListModel.dart';
import 'package:ai_powered_app/screen/jobs.screen/job.details.screen.dart';
import 'package:ai_powered_app/screen/jobs.screen/profileScreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import '../../data/providers/jobListingProvider.dart';
import 'basic.info.screen.dart';
import 'jobsResistractionScreen.dart';
import 'myJobScreen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int bottomTab = 0;
  int tab = 0;
  final PageController _pageController = PageController();
  DateTime? lastBackPressTime;

  String? userId;
  String? employerId;

  List<Map<String, dynamic>> joblist = [
    {
      "imageUrl": "assets/full.png",
      "position": "Full Stack Developer",
      "remote": "Remote",
      "part": "Full Time",
      "salary": "₹15000-₹25000",
      "location": "Mansarovar, Jaipur",
    },
    {
      "imageUrl": "assets/ui.png",
      "position": "UI/UX Designer",
      "remote": "Hybrid",
      "part": "Part Time",
      "salary": "₹8000-₹12000",
      "location": "Banjara Hills, Hyderabad",
    },
    {
      "imageUrl": "assets/full.png",
      "position": "Data Analyst",
      "remote": "Remote",
      "part": "On-site", // Corrected spelling
      "salary": "₹15000-₹25000",
      "location": "Mansarovar, Jaipur",
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    final box = await Hive.openBox('userdata');
    setState(() {
      userId = box.get('userName');
      employerId = box.get('employer_id')?.toString(); // ✅ Convert to String
    });
    debugPrint('User Name: $userId');
    debugPrint('Employer ID: $employerId');
  }


  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    final jobsList = ref.watch(jobListingsProvider);

    if (userId == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return WillPopScope(
        onWillPop: () async {
          if (bottomTab != 0) {
            _pageController.jumpToPage(0);
            setState(() => bottomTab = 0);
            return false;
          }

          final now = DateTime.now();
          if (lastBackPressTime == null || now.difference(lastBackPressTime!) > const Duration(seconds: 2)) {
            lastBackPressTime = now;
            Fluttertoast.showToast(
              msg: "Press back again to exit",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
            );
            return false;
          }
          return true;
        },
        child: Scaffold(
          backgroundColor: const Color(0xFFF5F8FA),
          body: PageView(
            controller: _pageController,
            physics: const NeverScrollableScrollPhysics(),
            onPageChanged: (index) {
              setState(() => bottomTab = index);
            },
            children: [
              _buildHomeContent(jobsList),
              const JobsResistrationScreen(),
              const MyJobApplication(),
              employerId == null || employerId!.isEmpty
                  ? const ProfileScreen()
                  : const BasicInfoScreen(),
            ],
          ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.only(left: 20.w, right: 20.w, bottom: 20.h),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20.r),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0A66C2),
              borderRadius: BorderRadius.circular(20.r),
            ),
            child: BottomNavigationBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              currentIndex: bottomTab,
              onTap: (index) {
                _pageController.jumpToPage(index);
                setState(() {
                  bottomTab = index;
                });
              },
              type: BottomNavigationBarType.fixed,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.white60,
              showUnselectedLabels: true,
              showSelectedLabels: true,
              selectedLabelStyle: GoogleFonts.alexandria(
                fontSize: 15.sp,
                fontWeight: FontWeight.w500,
                letterSpacing: -0.2,
              ),
              unselectedLabelStyle: GoogleFonts.gothicA1(
                fontSize: 15.sp,
                fontWeight: FontWeight.w400,
                letterSpacing: -0.2,
              ),
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                BottomNavigationBarItem(
                  icon: Icon(Icons.explore_outlined),
                  label: 'Browse',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.work_outline),
                  label: 'My Job',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person_outlined),
                  label: 'Profile',
                ),
              ],
            ),
          ),
        ),
      ),
    )   );
  }

  Widget _buildHomeContent(AsyncValue<JobListModel> jobsList) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 60.h),
          Row(
            children: [
              SizedBox(width: 24.w),
              Container(
                width: 40.w,
                height: 40.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.r),
                  color: const Color(0xFF0A66C2),
                ),
                child: Center(
                  child: Image.asset(
                    "assets/rajveer.png",
                    color: const Color(0xFFFFFFFF),
                  ),
                ),
              ),
              SizedBox(width: 10.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Job Portal",
                    style: GoogleFonts.alexandria(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF030016),
                      letterSpacing: -1,
                    ),
                  ),
                  Text(
                    '$userId',
                    style: GoogleFonts.alexandria(
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF9A97AE),
                      letterSpacing: -1,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                width: 40.w,
                height: 40.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(color: Colors.black12, width: 1.w),
                ),
                child: const Center(child: Icon(Icons.notifications_none)),
              ),
              SizedBox(width: 24.w),
            ],
          ),
          SizedBox(height: 16.h),
          Padding(
            padding: EdgeInsets.only(left: 24.w, right: 24.w),
            child: TextField(
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(
                  left: 20.w,
                  top: 20.h,
                  bottom: 20.h,
                  right: 20.w,
                ),
                filled: true,
                fillColor: const Color(0xFFE6EDF2),
                hintText: "Search your job",
                hintStyle: GoogleFonts.alexandria(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF030016),
                  letterSpacing: -1,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.r),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.r),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          SizedBox(height: 30.h),
          Padding(
            padding: EdgeInsets.only(left: 24.w),
            child: Text(
              "Browse by categories",
              style: GoogleFonts.alexandria(
                fontSize: 20.sp,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF030016),
                letterSpacing: -1,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 24.w, right: 24.h, top: 5.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CategoryBody(name: "Designer"),
                    CategoryBody(name: "Developer"),
                    CategoryBody(name: "Product Manager"),
                    CategoryBody(name: "UX Researcher"),
                  ],
                ),
                SizedBox(height: 10.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CategoryBody(name: "Content Strategist"),
                    CategoryBody(name: "Marketing Specialist"),
                    CategoryBody(name: "Data\nAnalyst"),
                    CategoryBody(name: "See More"),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 30.h),
          Padding(
            padding: EdgeInsets.only(left: 24.w, right: 24.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Recommend Jobs",
                  style: GoogleFonts.alexandria(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF030016),
                    letterSpacing: -1,
                  ),
                ),
                SizedBox(height: 15.h),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          tab = 0;
                        });
                      },
                      child: RecomandedBody(
                        name: "All",
                        bgColor: tab == 0 ? Colors.white : Colors.transparent,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          tab = 1;
                        });
                      },
                      child: RecomandedBody(
                        name: "Remote",
                        bgColor: tab == 1 ? Colors.white : Colors.transparent,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          tab = 2;
                        });
                      },
                      child: RecomandedBody(
                        name: "Onsite",
                        bgColor: tab == 2 ? Colors.white : Colors.transparent,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          tab = 3;
                        });
                      },
                      child: RecomandedBody(
                        name: "Full Time",
                        bgColor: tab == 3 ? Colors.white : Colors.transparent,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          tab = 4;
                        });
                      },
                      child: RecomandedBody(
                        name: "Part Time",
                        bgColor: tab == 4 ? Colors.white : Colors.transparent,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          jobsList.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text("Error: $e")),
            data: (searchModel) {
              final List<Job> results = searchModel.jobs;
              return ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: results.length,
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            CupertinoPageRoute(
                              builder: (context) => JobDetailsScreen(
                                  results[index].jobId.toString()),
                            ),
                          );
                        },
                        child: Container(
                          margin: EdgeInsets.only(
                            left: 24.w,
                            right: 24.w,
                            bottom: 20.h,
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20.r),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                offset: const Offset(0, 10),
                                blurRadius: 40,
                                spreadRadius: 0,
                                color: const Color.fromARGB(12, 10, 102, 194),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: 20.w,
                              right: 20.w,
                              top: 20.h,
                              bottom: 20.h,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 44.w,
                                      height: 44.h,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.grey,
                                      ),
                                      child: ClipOval(
                                        child: Image.asset(
                                          joblist[index]["imageUrl"].toString(),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 10.w),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          results[index].title,
                                          style: GoogleFonts.alexandria(
                                            fontSize: 14.sp,
                                            fontWeight: FontWeight.w500,
                                            color: const Color(0xFF1E1E1E),
                                            letterSpacing: -1,
                                          ),
                                        ),
                                        Text(
                                          "JPLoft Pvt. Ltd",
                                          style: GoogleFonts.alexandria(
                                            fontSize: 11.sp,
                                            fontWeight: FontWeight.w500,
                                            color: const Color(0xFF9A97AE),
                                            letterSpacing: -0.2,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(height: 15.h),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.location_on_outlined,
                                      size: 20.sp,
                                      color: const Color(0xFF9A97AE),
                                    ),
                                    SizedBox(width: 6.w),
                                    Text(
                                      joblist[index]["location"].toString(),
                                      style: GoogleFonts.alexandria(
                                        fontSize: 11.sp,
                                        fontWeight: FontWeight.w500,
                                        color: const Color(0xFF9A97AE),
                                        letterSpacing: -0.2,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10.h),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.attach_money,
                                      size: 20.sp,
                                      color: const Color(0xFF9A97AE),
                                    ),
                                    SizedBox(width: 6.w),
                                    Text(
                                      joblist[index]['salary'].toString(),
                                      style: GoogleFonts.alexandria(
                                        fontSize: 11.sp,
                                        fontWeight: FontWeight.w500,
                                        color: const Color(0xFF9A97AE),
                                        letterSpacing: -0.2,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 25.h),
                                Row(
                                  children: [
                                    Container(
                                      width: 69.w,
                                      height: 28.h,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE6EDF2),
                                        borderRadius: BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: Text(
                                          joblist[index]['remote'].toString(),
                                          style: GoogleFonts.alexandria(
                                            fontSize: 11.sp,
                                            fontWeight: FontWeight.w400,
                                            color: const Color(0xFF1E1E1E),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 10.h),
                                    Container(
                                      width: 73.w,
                                      height: 28.h,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE6EDF2),
                                        borderRadius: BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: Text(
                                          joblist[index]['part'].toString(),
                                          style: GoogleFonts.alexandria(
                                            fontSize: 11.sp,
                                            fontWeight: FontWeight.w400,
                                            color: const Color(0xFF1E1E1E),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const Spacer(),
                                    Container(
                                      width: 80.w,
                                      height: 32.h,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF0A66C2),
                                        borderRadius: BorderRadius.circular(40.r),
                                      ),
                                      child: Center(
                                        child: Text(
                                          "Apply",
                                          style: GoogleFonts.alexandria(
                                            fontSize: 15.sp,
                                            fontWeight: FontWeight.w400,
                                            color: const Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

class RecomandedBody extends StatelessWidget {
  final String name;
  final Color bgColor;
  const RecomandedBody({super.key, required this.name, required this.bgColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 15.w,
        right: 15.w,
        top: 10.h,
        bottom: 10.h,
      ),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(40.r),
      ),
      child: Center(
        child: Text(
          name,
          style: GoogleFonts.alexandria(
            fontSize: 11.sp,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF1E1E1E),
          ),
        ),
      ),
    );
  }
}

class CategoryBody extends StatelessWidget {
  final String name;
  const CategoryBody({super.key, required this.name});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 91.w,
      height: 100.h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15.r),
        color: const Color(0xFFFFFFFF),
      ),
      child: Padding(
        padding: EdgeInsets.only(left: 14.w, top: 14.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              "assets/category.png",
              width: 24.w,
              height: 24.h,
              fit: BoxFit.cover,
            ),
            const Spacer(),
            Text(
              name,
              textAlign: TextAlign.left,
              style: GoogleFonts.alexandria(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF1E1E1E),
                letterSpacing: -1,
                height: 1.2,
              ),
            ),
            SizedBox(height: 14.h),
          ],
        ),
      ),
    );
  }
}