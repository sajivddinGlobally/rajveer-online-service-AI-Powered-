import 'dart:ui';
import 'package:ai_powered_app/data/models/MatchProfileModel.dart';
import 'package:ai_powered_app/data/providers/matchProfileBasedProvider.dart';
import 'package:ai_powered_app/screen/matrimony.screen/favourite.page.dart';
import 'package:ai_powered_app/screen/matrimony.screen/message.page.dart';
import 'package:ai_powered_app/screen/matrimony.screen/particular.home.page.dart';
import 'package:ai_powered_app/screen/matrimony.screen/profile.page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../data/models/profileBasedModel.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/profileModel.dart';
import '../../data/providers/profileGetDataProvider.dart';
import '../../data/providers/searcProfileBased.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  int tabBottom = 0;
  bool isLocked = true;
  DateTime? lastBackPressTime;
  @override
  Widget build(BuildContext context) {
    ref.listen<AsyncValue<ProfileModel>>(
      profileDataProvider,
          (previous, next) {
        if (next is AsyncData && previous != next) {
          // Profile data updated, trigger any UI updates if needed
          setState(() {});
        }
      },
    );
    final profile = ref.watch(profileDataProvider);
    final profileSearch = ref.watch(profileBasedSearchProvider);
    final matchProfileData = ref.watch(matchProfileBasedProvider);

    return WillPopScope(
        onWillPop: () async {
      if (tabBottom != 0) {
        setState(() {
          tabBottom = 0;
        });
        return false;
      }

      final now = DateTime.now();
      if (lastBackPressTime == null || now.difference(lastBackPressTime!) > Duration(seconds: 2)) {
        lastBackPressTime = now;
        Fluttertoast.showToast(msg: "Press back again to exit");
        return false; // Don't exit yet
      }
      return true; // Exit app
    },

    child: Scaffold(
      backgroundColor: Color(0xFFFDF6F8),
      body:
          tabBottom == 0
              ?
      Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 60.h),
                      Row(
                        children: [
                          SizedBox(width: 24.w),
                          Container(
                            width: 40.w,
                            height: 40.h,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.r),
                              color: Color(0xFFFE9F0F),
                            ),
                            child: Center(
                              child: Image.asset(
                                "assets/rajveer.png",
                                color: Colors.white,
                              ),
                            ),
                          ),
                          SizedBox(width: 10.w),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Location",
                                style: GoogleFonts.gothicA1(
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w500,
                                  color: Color(0xFF9A97AE),
                                ),
                              ),
                              Text(
                                "Thane, Maharashtra",
                                style: GoogleFonts.gothicA1(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w500,
                                  color: Color(0xFF030016),
                                  letterSpacing: -1,
                                ),
                              ),
                            ],
                          ),
                          Spacer(),
                          Container(
                            width: 40.w,
                            height: 40.h,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.r),
                              border: Border.all(
                                color: Colors.black12,
                                width: 1.w,
                              ),
                            ),
                            child: Center(
                              child: Icon(Icons.notifications_none),
                            ),
                          ),
                          SizedBox(width: 24.w),
                        ],
                      ),
                      SizedBox(height: 20.h),
                      Expanded(
                        child: DefaultTabController(
                          length: 2,
                          child: Column(
                            children: [
                              TabBar(
                                indicatorColor: Color(0xFFFE9F0F),
                                dividerColor: Color(0xFFDADADA),
                                labelColor: Color(0xFFFE9F0F),
                                unselectedLabelColor: Color(0xFF9A97AE),
                                indicatorWeight: 2.w,
                                indicatorSize: TabBarIndicatorSize.tab,
                                tabs: [
                                  Tab(
                                    child: Text(
                                      "For You",
                                      style: GoogleFonts.gothicA1(
                                        fontSize: 15.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                  Tab(
                                    child: Text(
                                      "Nearby",
                                      style: GoogleFonts.gothicA1(
                                        fontSize: 15.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20.h),


        Expanded(
        child: TabBarView(
        children: [
        profileSearch.when(
        loading: () => Center(child: CircularProgressIndicator()),
    error: (e, _) => Center(child: Text("Error: $e")),
    data: (searchModel) {
    final List<Result> results = searchModel.results;

    return Padding(
    padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 20.h),
    child: GridView.builder(
    itemCount: results.length,
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2,
    crossAxisSpacing: 20.w,
    mainAxisSpacing: 20.h,
    childAspectRatio: 0.95,
    ),
    itemBuilder: (context, index) {
    final user = results[index];

    return Container(
    padding: EdgeInsets.zero,
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(15.r),
    ),
    child: Stack(
    children: [
    ClipRRect(
    borderRadius: BorderRadius.circular(15.r),
    child:

    isLocked
    ?


    GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            CupertinoPageRoute(
              builder: (_) => PartnerPreferencePage(user.userId.toString()??""),
            ),
          );
        },
        child:

    ImageFiltered(
    imageFilter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
    child: user.photoThumbnail != null
    ? Image.network(
    user.photoThumbnail!,
    width: double.infinity,
    height: double.infinity,
    fit: BoxFit.cover,
    )
        : Image.asset(
    "assets/female.png",
    width: double.infinity,
    height: double.infinity,
    fit: BoxFit.cover,
    ),
    ))
        : GestureDetector(
    onTap: () {
    Navigator.push(
    context,
    CupertinoPageRoute(
    builder: (_) => PartnerPreferencePage(user.userId.toString()??""),
    ),
    );
    },
    child: Stack(
    children: [
    user.photoThumbnail != null
    ? Image.network(
    user.photoThumbnail!,
    width: double.infinity,
    height: double.infinity,
    fit: BoxFit.cover,
    )
        : Image.asset(
    "assets/female.png",
    width: double.infinity,
    height: double.infinity,
    fit: BoxFit.cover,
    ),
    Image.asset(
    "assets/femalebgimage.png",
    width: double.infinity,
    height: double.infinity,
    fit: BoxFit.cover,
    ),
    Positioned(
    left: 15.w,
    top: 15.h,
    child: Container(
    padding: EdgeInsets.symmetric(
    horizontal: 7.w,
    vertical: 5.h,
    ),
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(6.r),
    color: Color.fromARGB(100, 0, 3, 22),
    ),
    child: Row(
    children: [
    Image.asset(
    "assets/loca.png",
    color: Colors.white,
    ),
    SizedBox(width: 3.w),
    Text(
    user.location ?? "Unknown",
    style: GoogleFonts.gothicA1(
    fontSize: 10.sp,
    color: Colors.white,
    ),
    ),
    ],
    ),
    ),
    ),
    Positioned(
    bottom: 16.h,
    left: 16.w,
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    user.name,
    style: GoogleFonts.gothicA1(
    fontSize: 14.sp,
    fontWeight: FontWeight.w500,
    color: Colors.white,
    ),
    ),
    Text(
    user.age != null ? "${user.age} years old" : "",
    style: GoogleFonts.gothicA1(
    fontSize: 12.sp,
    fontWeight: FontWeight.w400,
    color: Color(0xFF9A97AE),
    ),
    ),
    ],
    ),
    ),
    ],
    ),
    ),
    ),
    // if (isLocked)
    Center(
    child: Icon(
    Icons.lock,
    color: Colors.white,
    size: 30.sp,
    ),
    ),
    ],
    ),
    );
    },
    ),
    );
    },
    ),

          matchProfileData.when(
            loading: () => Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text("Error: $e")),
            data: (searchModel) {
              final List<Match> results = searchModel.matches;

              return ListView.builder(
                itemCount: results.length,
                itemBuilder: (context, index) {
                  final match = results[index];
                  return Card(
                    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: ListTile(
                      leading: match.photoThumbnail!.isNotEmpty
                          ? Image.network(match.photoThumbnail??"", width: 50, height: 50, fit: BoxFit.cover)
                          : Image.asset('assets/female.png', width: 50, height: 50),
                      title: Text(match.name),
                      subtitle: Text("${match.age ?? 'N/A'} • ${match.location}"),
                      trailing: Text(match.status),
                      onTap: () {
                        // Navigate or show details
                      },
                    ),
                  );
                },
              );
            },
          )

    ],
    ),
    ),

    ],
                          ),
                        ),
                      ),
                    ],
    )
              :
          tabBottom == 1
              ? MessagePage()
              : tabBottom == 2
              ? UserViewedProfilesScreen()
              : ProfilePage(),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.only(left: 20.w, right: 20.w, bottom: 20.h),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20.r),
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFFFE9F0F),
              borderRadius: BorderRadius.circular(20.r),
            ),
            child: BottomNavigationBar(
              backgroundColor:
                  Colors.transparent, // Make nav bar background transparent
              elevation: 0, // Optional: remove shadow
              currentIndex: tabBottom,
              onTap: (value) {
                setState(() {
                  tabBottom = value;
                });
              },
              type: BottomNavigationBarType.fixed,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.white60,
              showUnselectedLabels: true,
              showSelectedLabels: true,
              selectedLabelStyle: GoogleFonts.gothicA1(
                fontSize: 15.sp,
                fontWeight: FontWeight.w500,
                letterSpacing: -0.2,
              ),
              unselectedLabelStyle: GoogleFonts.gothicA1(
                fontSize: 15.sp,
                fontWeight: FontWeight.w400,
                letterSpacing: -0.2,
              ),
              items: [
                BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                BottomNavigationBarItem(
                  icon: Icon(Icons.chat),
                  label: 'Message',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.favorite_border),
                  label: 'Favourite',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person_outlined),
                  label: 'Profile',
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}
